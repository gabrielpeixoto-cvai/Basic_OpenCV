#include "ocv_utils.h"

using namespace cv;
using namespace std;
using namespace ocv_utils;


/**  @function main */
int main( int argc, char** argv )
{
  Mat src, dst;
  Mat src_hist, dst_hist;


  /// Load image
  src = imread( argv[1], 1 );

  Mat rows;
  Mat columns;
  Mat window=src(Rect(0, 0, 3, 3));

  if( !src.data )
    { cout<<"Usage: ./Histogram_Demo <path_to_image>"<<endl;
      return -1;}

  /// Convert to grayscale
  cvtColor( src, src, CV_BGR2GRAY );

  /// Apply Histogram Equalization
  //equalizeHist( src, dst );

  cout<<"source dimentions rows:"<<src.rows<<"columns"<<src.cols<<endl;
  cout<<columns.cols<<rows.rows<<endl;
  cout<<window.rows<<endl;

  int i,j;
	for(i=1;i<src.rows-1;i++){
	   for(j=1;j<src.cols-1;j++){
				Mat roi=src(Rect(i-1, j-1, 3, 3));
        cout<<window.rows<<endl;
				equalizeHist(roi, roi);
        hconcat (window, roi, rows);
        window = rows.clone();
	  }
    vconcat (columns, rows, columns);
	}


  dst = columns.clone();

  // create histogram plots
  src_hist = plotHistogram (calcHistogram (src));
  dst_hist = plotHistogram (calcHistogram (dst));

  //resize and concatenate the images to show in one window
  resize (src, src, Size(512*src.cols/src.rows,512), 0, 0, INTER_CUBIC);
	resize (dst, dst, Size(512*dst.cols/dst.rows,512), 0, 0, INTER_CUBIC);
  resize (src_hist, src_hist, Size(512*src_hist.cols/src_hist.rows,512), 0, 0, INTER_CUBIC);
  resize (dst_hist, dst_hist, Size(512*dst_hist.cols/dst_hist.rows,512), 0, 0, INTER_CUBIC);
	hconcat (src, src_hist, src);
	hconcat (dst, dst_hist, dst);
	vconcat (src, dst, src);

	namedWindow(argv[0], CV_WINDOW_NORMAL);
    //setWindowProperty(argv[0], CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
	imshow(argv[0], src);

	cv::waitKey (0);

  return 0;
}
